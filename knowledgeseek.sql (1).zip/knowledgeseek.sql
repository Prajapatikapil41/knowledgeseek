-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2021 at 02:24 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knowledgeseek`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_data`
--

CREATE TABLE `admin_data` (
  `id` int(255) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `phone` bigint(102) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `status` int(6) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_data`
--

INSERT INTO `admin_data` (`id`, `username`, `phone`, `email`, `password`, `status`, `created_at`, `updated_at`) VALUES
(1, 'knowledgeseek', 7987798788, 'knowledgeseek21@gmail.com', '$2y$10$jqt1lbs/g0MMr9oXGQ8ga.5QRL2bz0D/0OUv5y4ffLYitQ1/0rR7O', 0, '2021-05-11 12:44:01.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(255) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `category_id` int(255) NOT NULL,
  `title` varchar(500) NOT NULL,
  `discription` varchar(5555) NOT NULL,
  `author` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `image`, `category_id`, `title`, `discription`, `author`, `status`, `created_at`, `updated_at`) VALUES
(1, '3d1c80c397f45bab0d813ca961073301.jpg', 5, 'magic robot magic car', '<p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lore</p><div style=\"margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><div class=\"col-12 col-md-12 col-lg-12 col-sm-12\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 1140px;\"><img src=\"https://source.unsplash.com/1500x500\" class=\"img-fluid\" alt=\"...\" style=\"margin: 0px; padding: 0px;\"><div style=\"margin: 0px; padding: 0px;\"></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0;\"><div class=\"col-12 col-lg-6 col-sm-12 col-md-6 \" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 570px; max-width: 100%;\"><h1 style=\"margin-right: 0px; margin-left: 0px; padding: 0px;\">Lorem Ipsum</h1><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p></div><div class=\"col-12 col-lg-6 col-sm-12 col-md-6\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 570px; max-width: 100%;\"><img src=\"https://images.unsplash.com/photo-1626881801495-38dedd276108?crop=entropy&amp;cs=tinysrgb&amp;fit=crop&amp;fm=jpg&amp;h=300&amp;ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTYyNjk0NTkxMw&amp;ixlib=rb-1.2.1&amp;q=80&amp;w=500\" class=\"rounded float-start\" alt=\"...\" style=\"margin: 0px; padding: 0px; float: left !important;\"></div></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0;\"><div class=\"col-12 col-md-12 col-lg-12 col-sm-12\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-r', 'BGMIs', 0, '2015-07-21 15:05:26.000000', '2024-07-21 22:44:43.000000'),
(3, '400d571033213a48147832f722cadc1a.jpg', 3, 'Lets, Contactfdddddddddds', '<p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lore</p><div style=\"margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><div class=\"col-12 col-md-12 col-lg-12 col-sm-12\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 1140px;\"><img src=\"https://source.unsplash.com/1500x500\" class=\"img-fluid\" alt=\"...\" style=\"margin: 0px; padding: 0px;\"><div style=\"margin: 0px; padding: 0px;\"></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0;\"><div class=\"col-12 col-lg-6 col-sm-12 col-md-6 \" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 570px; max-width: 100%;\"><h1 style=\"margin-right: 0px; margin-left: 0px; padding: 0px;\">Lorem Ipsum</h1><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p></div><div class=\"col-12 col-lg-6 col-sm-12 col-md-6\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 570px; max-width: 100%;\"><img src=\"https://images.unsplash.com/photo-1626881801495-38dedd276108?crop=entropy&amp;cs=tinysrgb&amp;fit=crop&amp;fm=jpg&amp;h=300&amp;ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTYyNjk0NTkxMw&amp;ixlib=rb-1.2.1&amp;q=80&amp;w=500\" class=\"rounded float-start\" alt=\"...\" style=\"margin: 0px; padding: 0px; float: left !important;\"></div></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0;\"><div class=\"col-12 col-md-12 col-lg-12 col-sm-12\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-r', 'magic man', 1, '2024-07-21 16:28:55.000000', '2024-07-21 22:33:10.000000'),
(4, '0db4d304cf6b9e87beb39987c12c99ca.jpg', 1, 'Lets, Contactfdddddddddds', '<p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lore</p><div style=\"margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0; color: rgb(33, 37, 41); font-family: system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><div class=\"col-12 col-md-12 col-lg-12 col-sm-12\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 1140px;\"><img src=\"https://source.unsplash.com/1500x500\" class=\"img-fluid\" alt=\"...\" style=\"margin: 0px; padding: 0px;\"><div style=\"margin: 0px; padding: 0px;\"></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0;\"><div class=\"col-12 col-lg-6 col-sm-12 col-md-6 \" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 570px; max-width: 100%;\"><h1 style=\"margin-right: 0px; margin-left: 0px; padding: 0px;\">Lorem Ipsum</h1><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p></div><div class=\"col-12 col-lg-6 col-sm-12 col-md-6\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: calc(var(--bs-gutter-x)/ 2); padding-bottom: 0px; padding-left: calc(var(--bs-gutter-x)/ 2); flex-basis: auto; width: 570px; max-width: 100%;\"><img src=\"https://images.unsplash.com/photo-1626881801495-38dedd276108?crop=entropy&amp;cs=tinysrgb&amp;fit=crop&amp;fm=jpg&amp;h=300&amp;ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTYyNjk0NTkxMw&amp;ixlib=rb-1.2.1&amp;q=80&amp;w=500\" class=\"rounded float-start\" alt=\"...\" style=\"margin: 0px; padding: 0px; float: left !important;\"></div></div><div class=\"row\" style=\"margin-top: 30px; margin-right: calc(var(--bs-gutter-x)/ -2); margin-bottom: 0px; margin-left: calc(var(--bs-gutter-x)/ -2); padding: 0px; --bs-gutter-x:1.5rem; --bs-gutter-y:0;\"><div class=\"col-12 col-md-12 col-lg-12 col-sm-12\" style=\"margin-top: var(--bs-gutter-y); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-r', 'BGMIs', 1, '2024-07-21 18:38:42.000000', '2024-07-21 21:03:53.000000');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `author` varchar(1000) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `book` mediumtext NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `author`, `subject_id`, `book`, `status`, `created_at`, `updated_at`) VALUES
(3, 'knowledge', 'raj', 2, 'knowledge.pdf', 1, '2021-07-22 15:20:45.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(255) NOT NULL,
  `programe_id` int(255) NOT NULL,
  `branch_name` varchar(5000) NOT NULL,
  `yearorsem_id` int(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `programe_id`, `branch_name`, `yearorsem_id`, `status`, `created_at`, `updated_at`) VALUES
(2, 3, 'BSC (micro organism)', 1, 1, '2021-07-15 14:33:31.000000', '2021-07-15 14:35:13.000000'),
(3, 1, 'CSE/IT', 2, 1, '2021-07-15 14:36:07.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'science', 1, '2015-07-21 15:01:53.000000', '2024-07-21 19:01:31.000000'),
(3, 'Technology', 1, '2015-07-21 15:02:14.000000', '0000-00-00 00:00:00.000000'),
(5, 'programming', 1, '2015-07-21 15:03:32.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `article_id` int(255) NOT NULL,
  `commented_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact_data`
--

CREATE TABLE `contact_data` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `message` varchar(5000) NOT NULL,
  `status` int(6) NOT NULL DEFAULT 0,
  `created_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_data`
--

INSERT INTO `contact_data` (`id`, `name`, `email`, `message`, `status`, `created_at`) VALUES
(1, 'aman', 'aman@gmail.com', 'hello', 0, '0000-00-00 00:00:00.000000'),
(2, 'aman pandagre', 'idraksheikh333@gmail.com', 'nnccab', 0, '0000-00-00 00:00:00.000000'),
(3, 'aman', 'aman@gmail.com', 'Cac', 0, '2014-05-21 11:53:13.000000'),
(4, 'aman pandagre', 'aman@gmail.com', 'c', 0, '2014-05-21 11:53:51.000000'),
(5, 'aman pandagre', 'idraksheikh333@gmail.com', 'bdbdb', 0, '2014-05-21 11:55:14.000000'),
(6, 'cv', 'aman@gmail.com', 'vvv', 0, '2014-05-21 11:55:44.000000'),
(7, 'kapil prajapati', 'kapil@gmail.com', 'hello firends chai pee loo......', 0, '2014-05-21 16:50:35.000000'),
(8, 'sandeep', 'aman@gmail.com', '<script>alert(\"hello\")</script>', 0, '2015-05-21 16:57:45.000000'),
(9, 'aman', 'aman@yahoo.com', 'tedd', 0, '2015-05-21 17:00:45.000000'),
(10, 'knowledge', 'seek@gmail.com', 'hello', 0, '2028-05-21 10:26:14.000000');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(255) NOT NULL,
  `name` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  `subject_id` int(255) NOT NULL,
  `syllabus_id` int(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `name`, `notes`, `subject_id`, `syllabus_id`, `status`, `created_at`, `updated_at`) VALUES
(2, 'nuclears', 'nuclears.pdf', 2, 3, 1, '2021-07-15 14:54:24.000000', '2021-07-15 14:56:43.000000'),
(4, 'knowledge', 'KnowledgeSeek_knowledge.pdf', 3, 6, 1, '2021-07-20 22:04:14.000000', '2021-07-22 09:53:29.000000'),
(5, 'nots', 'KNOWLEDGESEEKnots.pdf', 2, 5, 1, '2021-07-20 22:10:51.000000', '2021-07-21 14:15:02.000000'),
(6, 'kseek', 'kseek.pdf', 2, 7, 1, '2021-07-22 16:59:58.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

CREATE TABLE `papers` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `year` bigint(255) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `papers` varchar(10000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `papers`
--

INSERT INTO `papers` (`id`, `name`, `year`, `subject_id`, `papers`, `status`, `created_at`, `updated_at`) VALUES
(3, 'Maths', 2015, 2, 'Maths_2015.pdf', 1, '2021-07-15 14:59:47.000000', '0000-00-00 00:00:00.000000'),
(4, 'knowledge', 2019, 2, 'knowledge_2019.pdf', 1, '2021-07-22 11:34:49.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `programes`
--

CREATE TABLE `programes` (
  `id` int(255) NOT NULL,
  `programe_name` varchar(5000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programes`
--

INSERT INTO `programes` (`id`, `programe_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'B.TECH', 1, '2021-07-15 14:29:13.000000', '0000-00-00 00:00:00.000000'),
(3, 'BSC', 1, '2021-07-15 14:31:06.000000', '0000-00-00 00:00:00.000000'),
(4, 'MBA', 1, '2021-07-22 16:43:37.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `semsandyears`
--

CREATE TABLE `semsandyears` (
  `id` int(255) NOT NULL,
  `yos_id` int(255) NOT NULL,
  `sem_year` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semsandyears`
--

INSERT INTO `semsandyears` (`id`, `yos_id`, `sem_year`) VALUES
(1, 2, '1 sem'),
(2, 2, '2 sem'),
(3, 2, '3 sem'),
(4, 2, '4 sem'),
(5, 2, '5 sem'),
(6, 2, '6 sem'),
(7, 2, '7 sem'),
(8, 2, '8 sem'),
(9, 1, '1st year'),
(10, 1, '2nd year'),
(11, 1, '3rd year'),
(12, 1, '4th year'),
(13, 3, '1st year'),
(14, 3, '2nd year'),
(15, 3, '3rd year');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(255) NOT NULL,
  `sub_name` mediumtext NOT NULL,
  `subject_code` varchar(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `sub_name`, `subject_code`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Maths', 'BTMAC-454', 1, '2021-07-15 14:39:37.000000', '0000-00-00 00:00:00.000000'),
(3, 'physics', 'btpg-jsgnjisn', 1, '2021-07-20 12:36:55.000000', '0000-00-00 00:00:00.000000'),
(4, 'descerete', 'DFSF', 1, '2021-07-20 21:07:19.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `subjects_details`
--

CREATE TABLE `subjects_details` (
  `id` int(255) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `branch_id` int(255) NOT NULL,
  `sem_year_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects_details`
--

INSERT INTO `subjects_details` (`id`, `subject_id`, `branch_id`, `sem_year_id`) VALUES
(3, 2, 3, 3),
(4, 2, 3, 4),
(9, 3, 3, 3),
(10, 3, 2, 10),
(11, 2, 3, 1),
(12, 2, 3, 2),
(13, 4, 3, 1),
(14, 4, 3, 2),
(15, 4, 3, 3),
(16, 2, 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `syllabus`
--

CREATE TABLE `syllabus` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `syllabus_detail` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `syllabus`
--

INSERT INTO `syllabus` (`id`, `name`, `unit_id`, `subject_id`, `syllabus_detail`, `status`, `created_at`, `updated_at`) VALUES
(3, 'Physics MS', 1, 2, 'sems/yearssems/yearssems/yearssems/yearssems/yearssems/\r\nyearssems/yearssems/yearssems/yearssems/yearssems/yearss\r\nems/yearssems/yearssems/yearssems/yearssems/yearssems/yearssems/yearssems/yearssems/yearssems/yearssems/y\r\nears\r\n', 1, '2015-07-21 14:48:37.000000', '2020-07-21 21:33:29.000000'),
(5, 'aghawvj', 5, 2, 'sems/years  sems/years sems/years sems/yearsvsems/yearssems/yearssems/years sems/yearssems/yearssems/years', 1, '2015-07-21 14:49:33.000000', '2015-07-21 14:49:44.000000'),
(6, 'kseek', 1, 3, 'newArraynewArraynewArray/newArray/newArray/newArray/\r\nnewArray/newArray/newArray/newArray/newArray/newArray\r\nnewArray/newArraynewArray', 1, '2020-07-21 22:03:54.000000', '0000-00-00 00:00:00.000000'),
(7, 'knowledge', 2, 2, 'syllabusUnits/syllabusUnits/syllabusUnits/syllabusUnits/\r\nsyllabusUnits syllabusUnits syllabusUnits syllabusUnits\r\nsyllabusUnitssyllabusUnitssyllabusUnitssyllabusUnits', 1, '2021-07-21 14:25:05.000000', '0000-00-00 00:00:00.000000'),
(8, 'kseek', 3, 2, 'syllabusUnits/syllabusUnits/syllabusUnits/syllabusUnits/\r\nsyllabusUnits syllabusUnits syllabusUnits syllabusUnits\r\nsyllabusUnitssyllabusUnitssyllabusUnitssyllabusUnits', 1, '2021-07-21 14:25:18.000000', '0000-00-00 00:00:00.000000'),
(9, 'knowledge', 4, 2, 'syllabusUnits/syllabusUnits/syllabusUnits/syllabusUnits/\r\nsyllabusUnits syllabusUnits syllabusUnits syllabusUnits\r\nsyllabusUnitssyllabusUnitssyllabusUnitssyllabusUnitssyllabusUnits/syllabusUnits/syllabusUnits/syllabusUnits/\r\nsyllabusUnits syllabusUnits syllabusUnits syllabusUnits\r\nsyllabusUnitssyllabusUnitssyllabusUnitssyllabusUnits', 1, '2021-07-21 14:25:27.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(255) NOT NULL,
  `units` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `units`) VALUES
(1, 'UNIT-I'),
(2, 'UNIT-II'),
(3, 'UNIT-III'),
(4, 'UNIT-IV'),
(5, 'UNIT-V');

-- --------------------------------------------------------

--
-- Table structure for table `yearorsem`
--

CREATE TABLE `yearorsem` (
  `id` int(255) NOT NULL,
  `evs` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `yearorsem`
--

INSERT INTO `yearorsem` (`id`, `evs`) VALUES
(1, 'year wise'),
(2, 'semester wise'),
(3, '3 Year course'),
(4, '2 Year course');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_data`
--
ALTER TABLE `admin_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_data`
--
ALTER TABLE `contact_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `papers`
--
ALTER TABLE `papers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programes`
--
ALTER TABLE `programes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semsandyears`
--
ALTER TABLE `semsandyears`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects_details`
--
ALTER TABLE `subjects_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `syllabus`
--
ALTER TABLE `syllabus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `yearorsem`
--
ALTER TABLE `yearorsem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_data`
--
ALTER TABLE `admin_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_data`
--
ALTER TABLE `contact_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `papers`
--
ALTER TABLE `papers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `programes`
--
ALTER TABLE `programes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `semsandyears`
--
ALTER TABLE `semsandyears`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subjects_details`
--
ALTER TABLE `subjects_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `syllabus`
--
ALTER TABLE `syllabus`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `yearorsem`
--
ALTER TABLE `yearorsem`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
